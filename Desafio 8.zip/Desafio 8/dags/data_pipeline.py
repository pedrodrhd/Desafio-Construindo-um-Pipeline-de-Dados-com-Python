from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime, timedelta
import pandas as pd
import os

# Funções para processar os dados
def upload_raw_data_to_bronze():
    input_path = '/usr/local/airflow/data/raw_data.csv'
    bronze_path = '/usr/local/airflow/data/bronze/raw_data.csv'
    
    if os.path.exists(input_path):
        df = pd.read_csv(input_path)
        df.to_csv(bronze_path, index=False)
        print(f"Arquivo movido para camada bronze: {bronze_path}")
    else:
        raise FileNotFoundError(f"O arquivo de entrada {input_path} não foi encontrado.")

def process_bronze_to_silver():
    bronze_path = '/usr/local/airflow/data/bronze/raw_data.csv'
    silver_path = '/usr/local/airflow/data/silver/cleaned_data.csv'
    
    if os.path.exists(bronze_path):
        df = pd.read_csv(bronze_path)
        df = df.dropna(subset=['nome', 'email', 'data_nascimento'])
        df['email'] = df['email'].apply(lambda x: x if '@' in x else None)
        df['idade'] = pd.to_datetime('today').year - pd.to_datetime(df['data_nascimento']).dt.year
        df.to_csv(silver_path, index=False)
        print(f"Arquivo movido para camada silver: {silver_path}")
    else:
        raise FileNotFoundError(f"O arquivo de entrada {bronze_path} não foi encontrado.")

def process_silver_to_gold():
    silver_path = '/usr/local/airflow/data/silver/cleaned_data.csv'
    gold_path = '/usr/local/airflow/data/gold/transformed_data.csv'
    
    if os.path.exists(silver_path):
        df = pd.read_csv(silver_path)
        df['faixa_etaria'] = pd.cut(df['idade'], bins=[0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100],
                                    labels=['0-10', '11-20', '21-30', '31-40', '41-50', '51-60', '61-70', '71-80', '81-90', '91-100'])
        df['status'] = df['status'].apply(lambda x: 'active' if x == 1 else 'inactive')
        aggregated_data = df.groupby(['faixa_etaria', 'status']).size().reset_index(name='count')
        aggregated_data.to_csv(gold_path, index=False)
        print(f"Arquivo movido para camada gold: {gold_path}")
    else:
        raise FileNotFoundError(f"O arquivo de entrada {silver_path} não foi encontrado.")

# Configuração do DAG
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2023, 7, 24),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

dag = DAG(
    'data_pipeline',
    default_args=default_args,
    description='Pipeline de dados com Airflow',
    schedule_interval=timedelta(days=1),
)

# Definição das tarefas
t1 = PythonOperator(
    task_id='upload_raw_data_to_bronze',
    python_callable=upload_raw_data_to_bronze,
    dag=dag,
)

t2 = PythonOperator(
    task_id='process_bronze_to_silver',
    python_callable=process_bronze_to_silver,
    dag=dag,
)

t3 = PythonOperator(
    task_id='process_silver_to_gold',
    python_callable=process_silver_to_gold,
    dag=dag,
)

t1 >> t2 >> t3
